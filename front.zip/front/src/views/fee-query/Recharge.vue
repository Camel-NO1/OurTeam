<template>
  <div class="page-container">
    <h1>充值查询</h1>
  </div>
</template>

<style scoped>
.page-container {
  padding: 20px;
}
</style>