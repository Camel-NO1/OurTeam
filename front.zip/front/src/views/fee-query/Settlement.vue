<template>
  <div class="page-container">
    <h1>就诊卡结算查询</h1>
  </div>
</template>

<style scoped>
.page-container {
  padding: 20px;
}
</style>