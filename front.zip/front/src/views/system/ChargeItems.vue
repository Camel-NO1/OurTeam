<template>
  <div class="page-container">
    <h1>收费记录</h1>
    <p>这里是收费记录页面内容</p>
  </div>
</template>

<style scoped>
.page-container {
  padding: 20px;
}
</style>