<template>
  <div class="page-container">
    <h1>字典</h1>

  </div>
</template>

<style scoped>
.page-container {
  padding: 20px;
}
</style>