<template>
  <div class="page-container">
    <h1>a/r</h1>
    <p>an//r</p>
  </div>
</template>

<style scoped>
.page-container {
  padding: 20px;
}
</style>