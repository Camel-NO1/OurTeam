<template>
  <div class="page-container">
    <h1>业务报表</h1>

  </div>
</template>

<style scoped>
.page-container {
  padding: 20px;
}
</style>