<template>
  <div class="page-container">
    <h1>日结报表</h1>

  </div>
</template>

<style scoped>
.page-container {
  padding: 20px;
}
</style>